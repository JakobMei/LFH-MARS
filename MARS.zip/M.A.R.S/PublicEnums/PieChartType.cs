﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace M.A.R.S.PublicEnums
{
    public enum PieChartType
    {
        Input,
        Output
    }
}
