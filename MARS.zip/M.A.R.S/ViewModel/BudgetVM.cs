﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace M.A.R.S.ViewModel
{
    public class BudgetVM
    {
        public double Budget { get; set; }
        public double OpenBudget { get; set; }

        public double TotalImpact { get; set; }
    }
}
